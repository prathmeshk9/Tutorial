import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


public class HibernateUtil {
	static Configuration config;
	static SessionFactory sessionFactory;
	static{
		config = new Configuration().configure();
		sessionFactory = config.buildSessionFactory();
	}
	public static Configuration getConfig() {
		return config;
	}
	public static SessionFactory getSessionFactory() {
		return sessionFactory;
	}
}
