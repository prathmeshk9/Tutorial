import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.tool.hbm2ddl.SchemaExport;

import pack.Address;
import pack.User;


public class Main {
	public static void main(String[] args) {
		//SchemaExport se = new SchemaExport(HibernateUtil.getConfig());
		//se.create(true, true);
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		User user = new User();
		user.setFname("krishna");
		user.setLname("kale");
		
		Address address = new Address();
		address.setStreet("Nagar");
		address.setCity("Pune");
		address.setState("Maharastra");
		
		user.setAddress(address);
		address.setUser(user);
		
		session.save(user);
		tx.commit();
		session.close();
	}
}
