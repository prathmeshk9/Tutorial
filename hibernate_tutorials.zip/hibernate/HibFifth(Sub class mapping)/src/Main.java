import org.hibernate.Session;
import org.hibernate.Transaction;

import pack.BankAccount;
import pack.CreditCard;


public class Main {
	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		CreditCard c = new CreditCard();
		c.setCno(12345);
		c.setExpdate("1/7/12");
		c.setOwner("krishna");
		BankAccount b = new BankAccount();
		b.setAcno(101);
		b.setBname("Axis");
		b.setOwner("ram");
		session.save(c);
		session.save(b);
		tx.commit();
		session.close();
	}
}
