import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import emp.Department;
import emp.Employee;


public class CriteriaDemo {
	public static void main(String[] args) {
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		System.out.println("*****************Create criteria***************************");
		
		Criteria c = session.createCriteria(Employee.class);
		c.add(Restrictions.gt("eno",new Integer(0)));
		List<Employee> l = c.list();
		Iterator<Employee> it = l.iterator();
		while (it.hasNext()) {
			Employee employee = it.next();
			System.out.println("Employee No : "+employee.getEno()+" Employee Name : "+employee.getEname());
		}
		
		System.out.println("*****************Using and combonation of Restictions ***************************");
		
		Criteria c1 = session.createCriteria(Employee.class);
		c1.add(Restrictions.or(Restrictions.gt("eno",0),Restrictions.like("ename","%k")));
		List<Employee> l1 = c1.list();
		Iterator<Employee> it1 = l1.iterator();
		while (it1.hasNext()) {
			Employee employee = it1.next();
			System.out.println("Employee No : "+employee.getEno()+" Employee Name : "+employee.getEname());
		}
		
		System.out.println("*****************Ascending Order***************************");
		
		Criteria c2 = session.createCriteria(Employee.class);
		c2.addOrder(Order.asc("ename"));
		List<Employee> l2 = c2.list();
		Iterator<Employee> it2 = l2.iterator();
		while (it2.hasNext()) {
			Employee employee = it2.next();
			System.out.println("Employee No : "+employee.getEno()+" Employee Name : "+employee.getEname());
		}
		
		System.out.println("*****************Select Projections ***************************");
		
		Criteria c3 = session.createCriteria(Employee.class);
		c3.setProjection(Projections.property("ename"));
		List<Object> l3 = c3.list();
		Iterator<Object> it3 = l3.iterator();
		while (it3.hasNext()) {
			String ename = (String) it3.next();
			System.out.println("Employee Name : "+ename);
		}
		tx.commit();
		session.close();
	}
}
