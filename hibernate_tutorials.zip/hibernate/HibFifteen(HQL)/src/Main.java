import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.tool.hbm2ddl.SchemaExport;

import emp.Department;
import emp.Employee;


public class Main {
	public static void main(String[] args) {
		//SchemaExport se = new SchemaExport(HibernateUtil.getConfig());
		//se.create(true, true);
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		/*Employee e = new Employee();
		e.setEname("krishna");
		e.setEsal(10000);
		
		Department d = new Department();
		d.setDname("C devloper");
		e.setDept(d);
		session.save(e);
		
		Employee e1 = new Employee();
		e1.setEname("ram");
		e1.setEsal(10000);
		
		Department d1 = new Department();
		d1.setDname("C devloper");
		e1.setDept(d1);
		session.save(e1);*/
		
		System.out.println("*****************from cluase***************************");
		Query q = session.createQuery("from Employee");
		
		List<Employee> l1 = q.list();
		Iterator<Employee> i1 = l1.iterator();
		
		while (i1.hasNext()) {
			Employee employee = i1.next();
			System.out.println("Employee Name :"+employee.getEname());
			System.out.println("Employee Salary :"+employee.getEsal());
		}
		
		System.out.println("*****************where cluase and positional parameter***************************");
		
		Query q1 = session.createQuery("from Department d where d.dno = ?");
		q1.setParameter(0,new Integer(2)); 
		List<Department> o1 = q1.list();
		Iterator<Department> it1 = o1.iterator();
		while (it1.hasNext()) {
			Department objects = (Department) it1.next();
			System.out.println("Department no: "+objects.getDno()+"\nDepartment name: "+objects.getDname());
		}
		
		System.out.println("*****************Named parameter***************************");
		
		Query q3 = session.createQuery("from Department d where d.dno=:dn");
		q3.setParameter("dn",new Integer(2)); 
		List<Department> o2 = q1.list();
		Iterator<Department> it2 = o2.iterator();
		while (it2.hasNext()) {
			Department objects = (Department) it2.next();
			System.out.println("Department no: "+objects.getDno()+"\nDepartment name: "+objects.getDname());
		}
		
		System.out.println("*****************Select Cluase (Projections)***************************");
		
		Query q4 = session.createQuery("select d.dno,d.dname from Department d");
		List<Object[]> l = q4.list();
		Iterator<Object[]> i4 = l.iterator();
		while (i4.hasNext()) {
			Object[] object = i4.next();
			System.out.println("Employee no :"+object[0]+"Employee Name :"+object[1]);
		}
		tx.commit();
		session.close();
	}
}
