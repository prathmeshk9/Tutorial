import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;


public class NativeSQL {
	public static void main(String[] args) {
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		SQLQuery q1 = session.createSQLQuery("");
		tx.commit();
		session.close();
	}
}
