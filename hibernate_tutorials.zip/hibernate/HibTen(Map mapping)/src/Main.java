import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.tool.hbm2ddl.SchemaExport;

import pack.Item;


public class Main {
	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		//SchemaExport se = new SchemaExport(HibernateUtil.getConfig());
		//se.create(true, true);
		
		Item item = new Item();
		item.setName("Agarbti");
		item.getImages().put("a1","images1.jpg");
		item.getImages().put("a2","images2.jpg");
		item.getImages().put("a3","images1.jpg");
		item.getImages().put("a4","images3.jpg");
		item.getImages().put("a5","images4.jpg");
		
		session.save(item);
		tx.commit();
		session.close();
	}
}
