package pack;


import java.util.HashMap;
import java.util.Map;

public class Item {
	private int itemid;
	private String name;
	private Map<String,String> images = new HashMap<String,String>();
	
	public int getItemid() {
		return itemid;
	}
	public void setItemid(int itemid) {
		this.itemid = itemid;
	}
	public void setImages(Map<String, String> images) {
		this.images = images;
	}
	public Map<String, String> getImages() {
		return images;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
