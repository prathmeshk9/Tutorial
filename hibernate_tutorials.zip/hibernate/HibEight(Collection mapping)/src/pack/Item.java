package pack;

import java.util.ArrayList;
import java.util.Collection;

public class Item {
	private int itemid;
	private String name;
	private Collection<String> images = new ArrayList<String>();
	
	public int getItemid() {
		return itemid;
	}
	public void setItemid(int itemid) {
		this.itemid = itemid;
	}
	public Collection<String> getImages() {
		return images;
	}
	public void setImages(Collection<String> images) {
		this.images = images;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
