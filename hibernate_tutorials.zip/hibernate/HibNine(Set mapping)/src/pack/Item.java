package pack;


import java.util.HashSet;
import java.util.Set;

public class Item {
	private int itemid;
	private String name;
	private Set<String> images = new HashSet<String>();
	
	public int getItemid() {
		return itemid;
	}
	public void setItemid(int itemid) {
		this.itemid = itemid;
	}
	public Set<String> getImages() {
		return images;
	}
	public void setImages(Set<String> images) {
		this.images = images;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
