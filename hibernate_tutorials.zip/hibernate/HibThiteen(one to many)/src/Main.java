import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.tool.hbm2ddl.SchemaExport;

import emp.Dept;
import emp.Employee;


public class Main {
	public static void main(String[] args) {
		//SchemaExport se = new SchemaExport(HibernateUtil.getConfig());
		//se.create(true, true);
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		Employee e1 = new Employee();
		e1.setName("Krishna1");
		
		Dept d1 = new Dept();
		d1.setDname("Computer1");
		d1.getEmployes().add(e1);
		
		e1.setDept(d1);
		session.save(e1);
		tx.commit();
		session.close();
	}
}
