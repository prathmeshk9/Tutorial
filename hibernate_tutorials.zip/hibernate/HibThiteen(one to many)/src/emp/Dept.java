package emp;

import java.util.ArrayList;
import java.util.Collection;

public class Dept {
	private int deptid;
	
	private String dname;
	
	private Collection<Employee> employes = new ArrayList<Employee>();

	public int getDeptid() {
		return deptid;
	}

	public void setDeptid(int deptid) {
		this.deptid = deptid;
	}

	public String getDname() {
		return dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	public Collection<Employee> getEmployes() {
		return employes;
	}

	public void setEmployes(Collection<Employee> employes) {
		this.employes = employes;
	}
	
	
}
