package pack;

public class BankAccount extends BillingDetails{
	private int acno;
	private String bname;
	public int getAcno() {
		return acno;
	}
	public String getBname() {
		return bname;
	}
	public void setAcno(int acno) {
		this.acno = acno;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
}
