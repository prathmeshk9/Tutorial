import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

import pack.BankAccount;
import pack.CreditCard;


public class Main {
	public static void main(String[] args) {
		Session session= HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		//SchemaExport ss = new SchemaExport(HibernateUtil.getConfig());    /*create table code */
		//ss.create(true,true);

		CreditCard c = new CreditCard();
		c.setCno(12345);
		c.setExpdate("1/2/12");
		c.setOwner("krishna");
		
		BankAccount b = new BankAccount();
		b.setAcno(101);
		b.setBname("SBI");
		b.setOwner("RAM");
		session.save(c);
		session.save(b);
		tx.commit();
		session.close();
	}
}
