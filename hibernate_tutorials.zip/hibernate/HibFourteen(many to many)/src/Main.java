import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.tool.hbm2ddl.SchemaExport;

import stud.Course;
import stud.Student;


public class Main {
	public static void main(String[] args) {
		//SchemaExport se = new SchemaExport(HibernateUtil.getConfig());
		//se.create(true, true);
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		Student s1 = new Student();
		s1.setName("krishna");
		
		Course c1 = new Course();
		c1.setName("JAVA");
		c1.getStudents().add(s1);
		
		Student s2 = new Student();
		s2.setName("ram");
		
		Course c2 = new Course();
		c2.setName("C");
		c2.getStudents().add(s2);
		
		Student s3 = new Student();
		s3.setName("ramkrishna");
		
		c2.getStudents().add(s3);
		
		
		session.save(s1);
		session.save(c1);
		session.save(s2);
		session.save(c2);
		session.save(s3);
		tx.commit();
		session.close();
	}
}
