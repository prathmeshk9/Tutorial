package stud;

import java.util.ArrayList;
import java.util.Collection;

public class Course {
	private int cid;
	
	private String name;
	
	private Collection<Student> students = new ArrayList<Student>();

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Collection<Student> getStudents() {
		return students;
	}

	public void setStudents(Collection<Student> students) {
		this.students = students;
	}
}
