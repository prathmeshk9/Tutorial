package stud;

import java.util.ArrayList;
import java.util.Collection;

public class Student {
	private int studid;
	
	private String name;
	
	private Collection<Course> courses = new ArrayList<Course>();

	public int getStudid() {
		return studid;
	}

	public void setStudid(int studid) {
		this.studid = studid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Collection<Course> getCourses() {
		return courses;
	}

	public void setCourses(Collection<Course> courses) {
		this.courses = courses;
	}
}
