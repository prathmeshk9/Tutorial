import org.hibernate.Session;
import org.hibernate.Transaction;

import pack.BankAccount;
import pack.CreditCard;


public class Main {
	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		CreditCard c = new CreditCard();
		c.setOwner("krishna");
		c.setCno(123456);
		c.setExpdate("15/7/12");
		
		BankAccount b = new BankAccount();
		b.setAcno(101);
		b.setBname("SBI");
		b.setOwner("ram");
		
		session.save(c);
		session.save(b);
		
		tx.commit();
		session.close();
	}
}
