import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import pack.Address;
import pack.User;


public class Main {
	public static void main(String[] args) {
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		User user = new User();
		user.setFname("krishna");
		user.setLname("kale");
		
		Address address = new Address();
		address.setStreet("samathNager");
		address.setCity("pune");
		address.setState("Maharastra");
		
		address.setStreet("krishnaNager");
		address.setCity("newyork");
		address.setState("Maharastra");
		
		user.setHome(address);
		user.setOffice(address);
		
		session.save(user);
		tx.commit();
		session.close();
	}
}
