import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import emp.Employee;


public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Configuration config = new Configuration().configure();
		SessionFactory sessionFactory = config.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		Employee e = new Employee();
		e.setEno(3);
		e.setEname("Ram");
		e.setEsal(12000);
		session.save(e);
		tx.commit();
		session.close();
	}

}
